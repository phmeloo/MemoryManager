package so;

public enum SystemCallType {
	CREATE_PROCESS, READ_PROCESS, WRITE_PROCESS, DELETE_PROCESS
}
