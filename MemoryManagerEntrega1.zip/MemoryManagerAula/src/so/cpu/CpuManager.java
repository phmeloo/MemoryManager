package so.cpu;

public class CpuManager {

}
